# Sprawozdanie 1 - obliczanie NDVI
## Autor - Karol Bogucki
## Prliminaria teoretyczne
### NDVI - Normalized Difference Vegetation Index
NDVI czyli znormalizowany różnicowy wskaźnik wegetacji służy do określania miejsc występowania kondycji i gęstości roślionności. Jego wartość znajduje się w zakresie od -1 do 1 gdzie wartości poniżej zera to woda czy chmury, wartości do 0,2 to budynki czy gleba zaś wyższe to już roślinność od szczątkowej do bujnej. Wskaźnik ten można wyliczyć ze wzoru:
NVDI = (NIR - RED) / (NIR + RED)

## Przebieg ćwiczenia
### Zakres ćwiczenia
Celem ćwiczenia było pobranie danych ze strony Copernicus Browser zawierającej dane z satelity Sentinel-2, zaimportowanie ich do progrmau QGIS i wyliczenie na ich podstawie wartości NDVI.
### Pobieranie danych

![alt text](image-1.png)
Oznaczamy obszar który nas interesuje i wybieramy datę wykonania zdjęć satelitarnych.

![alt text](image-2.png)
Wybieramy do pobrania dane z banda B04 czyli czerwonego, B08 czyli bliskiej podczerwieni oraz zdjęcia faktyczne i wyliczone NVDI dla porównania.

### Dodawanie mapy satelitarnej google
![alt text](dodawanie_googl.png)
Tworzymy połączenie ze stroną google aby pobrać mapę satelitarną na której będziemy mogli pracować.

### Wyliczanie NDVI

![alt text](image.png)
W zakładce kalkulatora rastrowego wyliczamy wskaźnik NDVI na podstawie wzoru podanego w preliminariach teoretycznych.

![alt text](image-3.png)
Zmieniamy styl warstwy zawierającej wyliczone przez nas NDVI aby można było wyraźnie zobaczyć jego wyniki.

### Wynik
![alt text](image-4.png)
![alt text](image-5.png)

Na powyższych rysunkach możemy zobaczyć wartwę NDVI oraz dla porównania warstwę z oryginalnymi kolorami. Na polach które są obrośnięte roślinami wartości NDVI są dodatnie co sprawia że przyjmują barwę zieloną na mapie. Z drugiej storny rzeka i jezioro przyjmują wyraźny czerwony kolor zgodnie z założeniem że powinny mieć wartość ujemną. 