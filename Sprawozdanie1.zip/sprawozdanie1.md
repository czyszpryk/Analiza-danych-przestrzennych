# Sprawozdanie 1 - obliczanie NDVI
## Autor - Karol Bogucki
## Prliminaria teoretyczne
### NDVI - Normalized Difference Vegetation Index
<p>
NDVI czyli znormalizowany różnicowy wskaźnik wegetacji służy do określania miejsc występowania kondycji i gęstości roślionności. Jego wartość znajduje się w zakresie od -1 do 1 gdzie wartości poniżej zera to woda czy chmury, wartości do 0,2 to budynki czy gleba zaś wyższe to już roślinność od szczątkowej do bujnej. Wskaźnik ten można wyliczyć ze wzoru:
NVDI = (NIR - RED) / (NIR + RED)
</p>

## Przebieg ćwiczenia
### Zakres ćwiczenia
<p>
Celem ćwiczenia było pobranie danych ze strony Copernicus Browser zawierającej dane z satelity Sentinel-2, zaimportowanie ich do progrmau QGIS i wyliczenie na ich podstawie wartości NDVI.
</p>

### Pobieranie danych

![alt text](image-1.png)
<p>Oznaczamy obszar który nas interesuje i wybieramy datę wykonania zdjęć satelitarnych.</p>

![alt text](image-2.png)
<p>Wybieramy do pobrania dane z banda B04 czyli czerwonego, B08 czyli bliskiej podczerwieni oraz zdjęcia faktyczne i wyliczone NVDI dla porównania.</p>

### Dodawanie mapy satelitarnej google
![alt text](dodawanie_googl.png)
<p>Tworzymy połączenie ze stroną google aby pobrać mapę satelitarną na której będziemy mogli pracować.</p>


### Wyliczanie NDVI

![alt text](image.png)
<p>W zakładce kalkulatora rastrowego wyliczamy wskaźnik NDVI na podstawie wzoru podanego w preliminariach teoretycznych.</p>


![alt text](image-3.png)
<p>Zmieniamy styl warstwy zawierającej wyliczone przez nas NDVI aby można było wyraźnie zobaczyć jego wyniki.</p>

### Wynik
![alt text](image-4.png)
![alt text](image-5.png)

<p>Na powyższych rysunkach możemy zobaczyć wartwę NDVI oraz dla porównania warstwę z oryginalnymi kolorami. Na polach które są obrośnięte roślinami wartości NDVI są dodatnie co sprawia że przyjmują barwę zieloną na mapie. Z drugiej storny rzeka i jezioro przyjmują wyraźny czerwony kolor zgodnie z założeniem że powinny mieć wartość ujemną. </p>

## Dane w wysokiej rozdzielczości

### Pobieranie danych w wysokiej rozdzielczości
![alt text](image-6.png)

![alt text](image-7.png)
<p>Pobieramy dane ze strony gov w kolorystyce CIR. Na pierwszy rzut oka można zobaczyć drastyczną różnicę w jakości między tymi danymi, a zdjęciami z Santinel'a. </p>

### Wyliczanie NVDI
![alt text](image-9.png)
<p>Wyliczamy NVDI ze wzoru podanego w preliminariach wykorzystując pierwszy i drugi band. W CIR na pierwszym miejscu znajduje się NIR, a na drugim Red.</p>

![alt text](image-10.png)
<p>Powstała warstwa z wyliczonym NVDI.</p>

### Podział mapy na działki administracyjne
![alt text](image-11.png)
<p>Wyznaczamy warstwę tymczasową zawierającą strefę której podział działek będziemy badać.</p>

![alt text](image-13.png)
<p>Wykorzystując wtyczkę pobieramy dane administracyjne podziału działek, po przetworzeniu powsstaje nam nowa warstwa skłądająca się z wydzielonych poligonów.</p>

### Wizualizacja średniego NVDI
![alt text](image-14.png)
<p>Za pomocą opcji tworzenia statystyk strefowych dla powstałej warstwy z działkami administracyjnymi na podstawie wyliczonego NVDI. To powoduje utworzenie kolejnej warswtwy zwierającej różne dane dla każdej ze stref. Stosując formatowanie stylów tworzymy podział na klasy na podstawie średniej wartości NVDI dla każdej działki.</p>

![alt text](image-15.png)
<p>W efekcie otrzymujemy wizualną reprezentację średniego NVDI dla każdej działki. Te które są polami są wyraźnie zielone, zaś zawierające budynki przyjmują żółte i pomarańczowe odcienie. Warto zauważyć że tworzenie stylów tworzy własną skalę kolorów niezależną od warstwy z wyliczonym NVDI. Przez to na mapie pojawia się działka zaznaczona kolorem czerwonym mimo że na obszarze nie znajdują się żadne zbiorniki wodne, a jest to jedynie największe zagęszczenie budynków. </p>